// src/content/config.ts
import { defineCollection, z } from 'astro:content';

/**
 * 产品集合Schema
 */
const productsCollection = defineCollection({
  type: 'content',
  schema: z.object({
    // 基本信息
    title: z.string(),
    slug: z.string(),
    category: z.enum([
      'copper',
      'aluminum',
      'nickel',
      'silver',
      'cca',
      'ccs',
      'ncc',
      'scc',
      'specialty',
    ]),
    productType: z.enum(['wire', 'flat-wire', 'strip', 'foil', 'ribbon', 'rod']),
    lang: z.enum(['en', 'cn']),

    // 描述
    shortDescription: z.string(),
    description: z.string(),

    // 关键词和标签
    keywords: z.array(z.string()),
    tags: z.array(z.string()).optional(),

    // 图片
    featuredImage: z.string(),
    images: z
      .array(
        z.object({
          src: z.string(),
          alt: z.string(),
          caption: z.string().optional(),
          width: z.number().optional(),
          height: z.number().optional(),
        })
      )
      .optional(),

    // 规格参数
    specifications: z
      .array(
        z.object({
          groupName: z.string(),
          specs: z.array(
            z.object({
              name: z.string(),
              value: z.union([z.string(), z.number()]),
              unit: z.string().optional(),
              range: z.string().optional(),
              tolerance: z.string().optional(),
            })
          ),
        })
      )
      .optional(),

    // 特性
    features: z
      .array(
        z.object({
          icon: z.string().optional(),
          title: z.string(),
          description: z.string(),
        })
      )
      .optional(),

    // 应用领域
    applications: z.array(z.string()).optional(),

    // 相关产品
    relatedProducts: z.array(z.string()).optional(),

    // 数据表
    datasheets: z
      .array(
        z.object({
          title: z.string(),
          url: z.string(),
          size: z.string().optional(),
          language: z.enum(['en', 'cn']),
        })
      )
      .optional(),

    // 认证
    certifications: z
      .array(
        z.object({
          name: z.string(),
          logo: z.string().optional(),
          number: z.string().optional(),
          validUntil: z.string().optional(),
        })
      )
      .optional(),

    // SEO
    seo: z.object({
      title: z.string(),
      description: z.string(),
      keywords: z.array(z.string()),
      ogImage: z.string().optional(),
      canonicalUrl: z.string().optional(),
    }),

    // 状态
    featured: z.boolean().optional(),
    inStock: z.boolean().optional(),
    weight: z.number().optional(),
    publishedAt: z.string().optional(),
    updatedAt: z.string().optional(),
  }),
});

/**
 * 应用领域集合Schema
 */
const applicationsCollection = defineCollection({
  type: 'content',
  schema: z.object({
    // 基本信息
    title: z.string(),
    slug: z.string(),
    category: z.enum([
      'photovoltaic-solar',
      'battery-storage',
      'electric-vehicles',
      'cable-wire',
      'electronics-pcb',
      'welding',
      'industrial-automation',
      'telecommunications',
    ]),
    lang: z.enum(['en', 'cn']),

    // 描述
    shortDescription: z.string(),
    description: z.string(),

    // 关键词
    keywords: z.array(z.string()),
    tags: z.array(z.string()).optional(),

    // 图片
    featuredImage: z.string(),
    images: z
      .array(
        z.object({
          src: z.string(),
          alt: z.string(),
          caption: z.string().optional(),
        })
      )
      .optional(),

    // 行业挑战
    challenges: z
      .array(
        z.object({
          title: z.string(),
          description: z.string(),
          icon: z.string().optional(),
        })
      )
      .optional(),

    // 解决方案
    solutions: z
      .array(
        z.object({
          title: z.string(),
          description: z.string(),
          productSlug: z.string().optional(),
          benefits: z.array(z.string()).optional(),
          icon: z.string().optional(),
        })
      )
      .optional(),

    // 技术优势
    advantages: z
      .array(
        z.object({
          title: z.string(),
          description: z.string(),
          metrics: z
            .array(
              z.object({
                name: z.string(),
                value: z.string(),
                unit: z.string().optional(),
              })
            )
            .optional(),
        })
      )
      .optional(),

    // 推荐产品
    recommendedProducts: z.array(z.string()).optional(),

    // 案例研究
    caseStudies: z
      .array(
        z.object({
          title: z.string(),
          client: z.string().optional(),
          challenge: z.string(),
          solution: z.string(),
          results: z.array(z.string()),
          image: z.string().optional(),
          slug: z.string().optional(),
        })
      )
      .optional(),

    // SEO
    seo: z.object({
      title: z.string(),
      description: z.string(),
      keywords: z.array(z.string()),
      ogImage: z.string().optional(),
      canonicalUrl: z.string().optional(),
    }),

    // 状态
    featured: z.boolean().optional(),
    weight: z.number().optional(),
    publishedAt: z.string().optional(),
    updatedAt: z.string().optional(),
  }),
});

/**
 * FAQ集合Schema
 */
const faqCollection = defineCollection({
  type: 'content',
  schema: z.object({
    // 基本信息
    question: z.string(),
    slug: z.string(),
    category: z.enum([
      'product-knowledge',
      'technical-specs',
      'applications',
      'buying-guide',
      'comparisons',
      'troubleshooting',
      'industry-insights',
    ]),
    lang: z.enum(['en', 'cn']),

    // 优先级和关键词
    priority: z.enum(['high', 'medium', 'low']).optional(),
    keywords: z.array(z.string()),
    tags: z.array(z.string()).optional(),

    // 快速答案
    quickAnswer: z.string(),

    // 相关信息
    relatedQuestions: z.array(z.string()).optional(),
    relatedProducts: z.array(z.string()).optional(),

    // 内容结构
    sections: z
      .array(
        z.object({
          heading: z.string(),
          content: z.string(),
        })
      )
      .optional(),

    keyTakeaways: z.array(z.string()).optional(),

    // SEO
    seo: z.object({
      title: z.string(),
      description: z.string(),
      keywords: z.array(z.string()),
      canonicalUrl: z.string().optional(),
    }),

    // 统计
    views: z.number().optional(),
    helpful: z.number().optional(),
    notHelpful: z.number().optional(),

    // 状态
    featured: z.boolean().optional(),
    weight: z.number().optional(),
    publishedAt: z.string().optional(),
    updatedAt: z.string().optional(),
  }),
});

/**
 * 博客集合Schema
 */
const blogCollection = defineCollection({
  type: 'content',
  schema: z.object({
    // 基本信息
    title: z.string(),
    slug: z.string(),
    description: z.string(),
    lang: z.enum(['en', 'cn']),

    // 作者和日期
    author: z.string().optional(),
    date: z.string(),
    updated: z.string().optional(),

    // 分类和标签
    category: z.string().optional(),
    tags: z.array(z.string()).optional(),

    // 图片
    featuredImage: z.string().optional(),
    excerpt: z.string().optional(),

    // 阅读时间
    readingTime: z.number().optional(),

    // SEO
    seo: z.object({
      title: z.string(),
      description: z.string(),
      keywords: z.array(z.string()),
    }),
  }),
});

/**
 * 导出所有集合
 */
export const collections = {
  products: productsCollection,
  applications: applicationsCollection,
  faq: faqCollection,
  blog: blogCollection,
};
