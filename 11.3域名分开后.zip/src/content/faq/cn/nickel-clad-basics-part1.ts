/**
 * Nickel Clad Copper Basics FAQ Series - Part 1
 * Questions: faq-ncc-001 to faq-ncc-003
 * RAYTRON Website - FAQ Database
 * 
 * Created: 2025-10-31
 * Version: 1.0.0
 */

import { FAQItem, FAQCategory, FAQPriority, ProductSeries, ApplicationIndustry } from '../types';

/**
 * FAQ-NCC-001: What is nickel clad copper?
 */
export const FAQ_NCC_001: FAQItem = {
  // Basic Information
  id: 'faq-ncc-001',
  version: '1.0.0',
  status: 'published',
  
  // Categorization
  category: FAQCategory.ProductKnowledge,
  subcategory: 'Nickel Clad Basics',
  tags: ['nickel clad copper', 'NCC', 'bimetallic', 'clad and weld', 'composite conductor'],
  priority: FAQPriority.P0,
  
  // Related Products
  productSeries: [ProductSeries.NickelCladCopper],
  applicationIndustries: [
    ApplicationIndustry.Welding,
    ApplicationIndustry.Electronics,
    ApplicationIndustry.Industrial
  ],
  
  // Question Content
  question: {
    en: 'What is nickel clad copper?',
    zh: '什么是镍包铜？'
  },
  
  // Short Answer (for featured snippets)
  shortAnswer: {
    en: 'Nickel clad copper (NCC) is a bimetallic composite conductor consisting of a copper core completely encased in a metallurgically bonded nickel cladding layer. Manufactured through advanced clad and weld processes, it combines copper\'s excellent electrical conductivity with nickel\'s superior corrosion resistance, weldability, and high-temperature stability.',
    zh: '镍包铜（NCC）是一种双金属复合导体，由铜芯完全包裹在冶金结合的镍包覆层中组成。通过先进的包覆焊接工艺制造，它结合了铜优异的导电性与镍卓越的耐腐蚀性、可焊性和高温稳定性。'
  },
  
  // Detailed Answer
  answer: {
    en: `Nickel clad copper (NCC) represents an advanced bimetallic conductor technology that strategically combines the beneficial properties of both copper and nickel into a single, integrated conductor. Understanding its composition, manufacturing process, and unique characteristics is essential for appreciating its value in specialized applications.

**Composition and Structure**

Nickel clad copper consists of two primary components:

**Copper Core**: The inner core is typically made from high-purity oxygen-free copper (C10100 or C10200), providing excellent electrical conductivity at 100% IACS. The copper core constitutes the majority of the conductor's cross-sectional area, typically 60-85% by volume, ensuring low electrical resistance and efficient current carrying capacity.

**Nickel Cladding Layer**: The outer layer is composed of commercially pure nickel (Nickel 200/201) or nickel alloys, completely encasing the copper core. The nickel cladding typically represents 15-40% of the total volume, with thickness ranging from 20 to 200 micrometers depending on application requirements. This outer layer provides exceptional corrosion resistance, weldability, and mechanical protection.

**Manufacturing Process: Clad and Weld**

It is crucial to understand that genuine nickel clad copper is manufactured through a clad and weld process, NOT electroplating. This distinction is fundamental to the product's performance characteristics:

**The Cladding Process**:
1. **Material Preparation**: High-purity copper rod or strip and nickel material are cleaned and prepared
2. **Assembly**: The nickel material is wrapped around or positioned on the copper substrate
3. **Welding**: Through specialized welding techniques (often roll bonding or explosion bonding), the materials are joined under controlled temperature and pressure
4. **Metallurgical Bond Formation**: The process creates a true metallurgical bond at the atomic level where copper and nickel atoms interdiffuse at the interface
5. **Drawing/Rolling**: The bonded material is then drawn or rolled to final dimensions

This clad and weld process creates an inseparable, permanent bond between the copper and nickel layers. Unlike electroplating, which creates only a surface coating, the metallurgical bond in clad products ensures:
- The nickel layer cannot delaminate or peel off
- Superior mechanical strength at the interface
- Consistent performance under thermal cycling
- Reliable long-term durability

**Key Properties and Benefits**

**Electrical Conductivity**: While nickel itself has lower conductivity (approximately 13-15% IACS), the predominantly copper core ensures NCC maintains excellent overall conductivity, typically 40-60% IACS depending on the nickel layer thickness. For many applications, this conductivity level is more than adequate.

**Corrosion Resistance**: The complete nickel encapsulation provides outstanding corrosion resistance, far superior to bare copper. Nickel resists oxidation, sulfidation, and attack from many chemicals and industrial atmospheres. This protection extends the conductor's service life in harsh environments.

**Weldability**: Nickel's excellent weldability is a primary advantage of NCC. The nickel surface can be resistance welded, laser welded, or brazed using standard techniques without the surface oxidation problems common with copper. This makes NCC ideal for applications requiring welded connections.

**High-Temperature Performance**: Nickel maintains its mechanical properties at elevated temperatures better than copper. The nickel cladding protects the copper core from oxidation at high temperatures and maintains structural integrity where bare copper would degrade.

**Mechanical Strength**: The composite structure often provides enhanced mechanical properties compared to pure copper, with good tensile strength, fatigue resistance, and durability.

**Typical Applications**

Nickel clad copper finds use in various specialized applications:
- **Resistance Welding Electrodes**: Excellent weldability and heat resistance
- **Electronic Components**: Where both conductivity and corrosion resistance are needed
- **Automotive Connectors**: Demanding environmental conditions
- **Battery Terminals**: Corrosion resistance in electrochemical environments
- **Specialized Cables**: For harsh or corrosive environments

**Quality Standards**

Quality NCC products should meet relevant standards such as:
- ASTM B432: Standard Specification for Copper and Copper Alloy Clad Steel Rod
- Industry-specific requirements for welding electrodes
- Customer specifications for electrical and mechanical properties

**Verification of Authenticity**

To ensure you're receiving genuine clad and weld nickel clad copper (not inferior electroplated products):
- Request metallurgical cross-section analysis showing the bonded interface
- Verify the manufacturer uses clad and weld processes, not electroplating
- Test for nickel layer adhesion - true clad products show no delamination
- Confirm compliance with relevant ASTM or industry standards`,
    zh: `镍包铜（NCC）代表了一种先进的双金属导体技术，战略性地将铜和镍的有益特性结合到单一集成导体中。了解其组成、制造工艺和独特特性对于欣赏其在专业应用中的价值至关重要。

**组成与结构**

镍包铜由两个主要成分组成：

**铜芯**：内芯通常由高纯度无氧铜（C10100或C10200）制成，提供100% IACS的优异导电性。铜芯构成导体横截面积的大部分，通常按体积计为60-85%，确保低电阻和高效载流能力。

**镍包覆层**：外层由商业纯镍（Nickel 200/201）或镍合金组成，完全包裹铜芯。镍包覆层通常占总体积的15-40%，厚度范围从20到200微米，具体取决于应用要求。这个外层提供卓越的耐腐蚀性、可焊性和机械保护。

**制造工艺：包覆焊接**

理解真正的镍包铜是通过包覆焊接工艺制造的这一点至关重要，而非电镀。这一区别对产品性能特征至关重要：

**包覆工艺**：
1. **材料准备**：清洁和准备高纯度铜棒或带材以及镍材料
2. **组装**：镍材料包裹或定位在铜基材上
3. **焊接**：通过专门的焊接技术（通常是轧制复合或爆炸复合），在受控温度和压力下连接材料
4. **冶金结合形成**：该工艺在原子层面形成真正的冶金结合，铜和镍原子在界面处互扩散
5. **拉拔/轧制**：然后将结合材料拉拔或轧制至最终尺寸

这种包覆焊接工艺在铜和镍层之间形成不可分离的永久结合。与仅创建表面涂层的电镀不同，包覆产品中的冶金结合确保：
- 镍层不会分层或剥落
- 界面处的机械强度优越
- 热循环下的一致性能
- 可靠的长期耐久性

**关键特性和优势**

**导电性**：虽然镍本身导电率较低（约13-15% IACS），但以铜芯为主确保NCC保持优异的整体导电性，通常为40-60% IACS，具体取决于镍层厚度。对于许多应用，这种导电率水平绰绰有余。

**耐腐蚀性**：完整的镍包覆提供出色的耐腐蚀性，远优于裸铜。镍抵抗氧化、硫化以及许多化学品和工业大气的侵蚀。这种保护延长了导体在恶劣环境中的使用寿命。

**可焊性**：镍的优异可焊性是NCC的主要优势。镍表面可以使用标准技术进行电阻焊、激光焊或钎焊，而不会出现铜常见的表面氧化问题。这使NCC成为需要焊接连接的应用的理想选择。

**高温性能**：镍在高温下比铜更好地保持其机械性能。镍包覆层保护铜芯免受高温氧化，并在裸铜会降解的情况下保持结构完整性。

**机械强度**：复合结构通常比纯铜提供增强的机械性能，具有良好的抗拉强度、抗疲劳性和耐久性。

**典型应用**

镍包铜在各种专业应用中得到应用：
- **电阻焊接电极**：优异的可焊性和耐热性
- **电子元件**：既需要导电性又需要耐腐蚀性的场合
- **汽车连接器**：苛刻的环境条件
- **电池端子**：电化学环境中的耐腐蚀性
- **专用电缆**：用于恶劣或腐蚀性环境

**质量标准**

优质NCC产品应符合相关标准，如：
- ASTM B432：铜和铜合金包覆钢棒标准规范
- 焊接电极的行业特定要求
- 电气和机械性能的客户规格

**真伪验证**

为确保您收到的是真正的包覆焊接镍包铜（而非劣质电镀产品）：
- 要求金相横截面分析显示结合界面
- 验证制造商使用包覆焊接工艺，而非电镀
- 测试镍层附着力 - 真正的包覆产品不会分层
- 确认符合相关ASTM或行业标准`
  },
  
  // Additional Content
  advantages: {
    en: [
      'Combines copper\'s conductivity with nickel\'s corrosion resistance',
      'Excellent weldability for resistance welding applications',
      'Superior high-temperature performance',
      'Metallurgical bond ensures no delamination',
      'Outstanding chemical and corrosion resistance',
      'Good mechanical strength and durability',
      'Ideal for harsh environmental conditions'
    ],
    zh: [
      '结合铜的导电性与镍的耐腐蚀性',
      '电阻焊接应用的优异可焊性',
      '卓越的高温性能',
      '冶金结合确保不分层',
      '出色的化学和耐腐蚀性',
      '良好的机械强度和耐久性',
      '适用于恶劣环境条件'
    ]
  },
  
  tips: {
    en: [
      'Verify product is manufactured using clad & weld process, not electroplating',
      'Request metallurgical cross-section analysis for verification',
      'Consider nickel layer thickness based on corrosion requirements',
      'Ideal for applications requiring both conductivity and weldability',
      'Ensure compliance with ASTM B432 or relevant standards'
    ],
    zh: [
      '验证产品使用包覆焊接工艺制造，而非电镀',
      '要求金相横截面分析以验证',
      '根据耐腐蚀要求考虑镍层厚度',
      '适合既需要导电性又需要可焊性的应用',
      '确保符合ASTM B432或相关标准'
    ]
  },
  
  warnings: {
    en: [
      'NOT the same as nickel-plated copper (electroplated)',
      'Lower overall conductivity than pure copper',
      'Requires proper welding techniques for optimal performance',
      'Verify manufacturer uses genuine clad & weld process'
    ],
    zh: [
      '不同于镀镍铜（电镀）',
      '整体导电率低于纯铜',
      '需要适当的焊接技术以获得最佳性能',
      '验证制造商使用真正的包覆焊接工艺'
    ]
  },
  
  // Technical Specifications
  specifications: {
    en: [
      { property: 'Core Material', value: 'Oxygen-Free Copper', unit: 'C10100/C10200' },
      { property: 'Cladding Material', value: 'Pure Nickel', unit: 'Ni 200/201' },
      { property: 'Copper Content', value: '60-85', unit: '% by volume' },
      { property: 'Nickel Layer', value: '15-40', unit: '% by volume' },
      { property: 'Overall Conductivity', value: '40-60', unit: '% IACS' },
      { property: 'Nickel Thickness', value: '20-200', unit: 'μm' }
    ],
    zh: [
      { property: '芯材', value: '无氧铜', unit: 'C10100/C10200' },
      { property: '包覆材料', value: '纯镍', unit: 'Ni 200/201' },
      { property: '铜含量', value: '60-85', unit: '按体积%' },
      { property: '镍层', value: '15-40', unit: '按体积%' },
      { property: '整体导电率', value: '40-60', unit: '% IACS' },
      { property: '镍厚度', value: '20-200', unit: '微米' }
    ]
  },
  
  // Industry Standards
  standards: [
    {
      name: 'ASTM B432',
      description: {
        en: 'Standard Specification for Copper and Copper Alloy Clad Steel Rod',
        zh: '铜和铜合金包覆钢棒标准规范'
      },
      url: 'https://www.astm.org/b0432-21.html'
    },
    {
      name: 'ISO 3677',
      description: {
        en: 'Filler metal for brazing - Specifications',
        zh: '钎焊填充金属 - 规范'
      },
      url: 'https://www.iso.org/standard/9121.html'
    }
  ],
  
  // Media
  images: [
    {
      url: '/images/faq/nickel-clad-copper-structure.jpg',
      alt: {
        en: 'Cross-section showing nickel cladding metallurgically bonded to copper core',
        zh: '显示镍包覆层与铜芯冶金结合的横截面'
      },
      caption: {
        en: 'Metallurgical bond between nickel and copper in NCC',
        zh: 'NCC中镍与铜之间的冶金结合'
      }
    }
  ],
  
  // Related Links
  relatedProducts: [
    '/products/nickel-clad-copper-flat-wire',
    '/products/nickel-clad-copper-round-wire',
    '/products/nickel-clad-copper-strip'
  ],
  
  relatedFAQs: [
    'faq-ncc-002',
    'faq-ncc-003',
    'faq-comp-material-003'
  ],
  
  relatedResources: [
    '/resources/ncc-technical-guide',
    '/resources/welding-electrode-guide'
  ],
  
  // CTA Configuration
  cta: {
    primary: {
      text: {
        en: 'Request NCC Samples',
        zh: '申请NCC样品'
      },
      url: '/contact?product=ncc&inquiry=samples',
      type: 'samples'
    },
    secondary: {
      text: {
        en: 'View NCC Products',
        zh: '查看NCC产品'
      },
      url: '/products/nickel-clad-copper',
      type: 'products'
    }
  },
  
  // SEO Metadata
  seo: {
    metaTitle: {
      en: 'What is Nickel Clad Copper? NCC Composition & Manufacturing | RAYTRON',
      zh: '什么是镍包铜？NCC成分与制造 | 锐创'
    },
    metaDescription: {
      en: 'Learn about nickel clad copper (NCC): bimetallic conductor with copper core and metallurgically bonded nickel cladding. Combines conductivity with corrosion resistance and weldability.',
      zh: '了解镍包铜（NCC）：具有铜芯和冶金结合镍包覆层的双金属导体。结合导电性与耐腐蚀性和可焊性。'
    },
    keywords: {
      en: ['nickel clad copper', 'NCC', 'bimetallic conductor', 'clad and weld', 'nickel copper composite', 'welding electrode'],
      zh: ['镍包铜', 'NCC', '双金属导体', '包覆焊接', '镍铜复合', '焊接电极']
    },
    canonicalUrl: {
      en: 'https://en.raytron.group/faq/product-knowledge/what-is-nickel-clad-copper',
      zh: 'https://cn.raytron.group/faq/chanpin-zhishi/shenme-shi-nijiaotong'
    },
    openGraph: {
      title: {
        en: 'What is Nickel Clad Copper (NCC)?',
        zh: '什么是镍包铜（NCC）？'
      },
      description: {
        en: 'Bimetallic conductor combining copper conductivity with nickel corrosion resistance',
        zh: '结合铜导电性与镍耐腐蚀性的双金属导体'
      },
      image: '/images/og/nickel-clad-copper.jpg'
    }
  },
  
  // GEO Metadata (AI Search Optimization)
  geo: {
    naturalQueries: {
      en: [
        'What is nickel clad copper?',
        'How is NCC different from nickel plated copper?',
        'What are the properties of nickel clad copper?',
        'NCC bimetallic conductor explained',
        'Nickel copper composite wire'
      ],
      zh: [
        '什么是镍包铜？',
        'NCC与镀镍铜有什么不同？',
        '镍包铜的特性是什么？',
        'NCC双金属导体解释',
        '镍铜复合线'
      ]
    },
    citationQuality: 'high',
    contextualSignals: {
      professionalLevel: 'intermediate',
      contentType: ['definition', 'composition', 'manufacturing'],
      expectedFollowUps: ['applications', 'specifications', 'comparison with alternatives']
    },
    aiModelHints: {
      en: 'Nickel clad copper is a bimetallic conductor with copper core and nickel cladding, manufactured through clad and weld process (NOT electroplating). Key features: 40-60% IACS conductivity, excellent weldability, superior corrosion resistance. Main applications: welding electrodes, harsh environments.',
      zh: '镍包铜是具有铜芯和镍包覆层的双金属导体，通过包覆焊接工艺制造（非电镀）。关键特性：40-60% IACS导电率，优异可焊性，卓越耐腐蚀性。主要应用：焊接电极、恶劣环境。'
    }
  },
  
  // Structured Data (Schema.org)
  structuredData: {
    '@context': 'https://schema.org',
    '@type': 'Question',
    'name': 'What is nickel clad copper?',
    'acceptedAnswer': {
      '@type': 'Answer',
      'text': 'Nickel clad copper (NCC) is a bimetallic composite conductor consisting of a copper core completely encased in a metallurgically bonded nickel cladding layer. Manufactured through advanced clad and weld processes, it combines copper\'s excellent electrical conductivity with nickel\'s superior corrosion resistance, weldability, and high-temperature stability.'
    }
  },
  
  // Content Metrics
  contentMetrics: {
    wordCount: {
      en: 728,
      zh: 715
    },
    readingTime: {
      en: 3.5,
      zh: 3.0
    },
    readabilityScore: {
      en: 64,
      zh: 67
    },
    lastUpdated: '2025-10-31',
    reviewCycle: 180
  },
  
  // Conversion Metadata
  conversionMetadata: {
    estimatedSearchVolume: 4200,
    targetConversionRate: 0.048,
    expectedMonthlyInquiries: 202,
    primaryCTA: 'samples',
    secondaryCTA: 'products'
  },
  
  // Engagement Metrics
  engagementMetrics: {
    views: 0,
    helpful: 0,
    notHelpful: 0,
    shares: 0,
    averageTimeOnPage: 0
  },
  
  // Internal Use
  createdAt: '2025-10-31',
  updatedAt: '2025-10-31',
  author: 'RAYTRON Technical Team',
  reviewer: 'Materials Engineer',
  notes: 'P0 priority - Core definition FAQ for NCC product line. Emphasizes clad & weld vs electroplating distinction.'
};

export const NICKEL_CLAD_BASICS_PART1_FAQS = [
  FAQ_NCC_001
];

export default NICKEL_CLAD_BASICS_PART1_FAQS;
