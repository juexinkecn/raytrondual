/**
 * FAQ Buying Guide: Lead Times for Standard vs Custom Conductors
 * 采购决策FAQ：标准与定制导体的交货期
 * 
 * SEO Focus: Delivery timeline expectations and acceleration options
 * Target Keywords: conductor lead time, wire delivery time, custom conductor delivery
 * Search Volume: 2,400/month
 * Conversion Rate: 5.0%
 * Estimated Monthly Inquiries: 120
 */

import { FAQ } from '../types';

export const faqBuying004: FAQ = {
  // ============================================================================
  // BASIC INFORMATION
  // ============================================================================
  id: 'faq-buying-004',
  category: 'Buying Guide',
  subcategory: 'Lead Times',
  priority: 'P0',
  
  // ============================================================================
  // BILINGUAL QUESTION
  // ============================================================================
  question: {
    en: "What Are the Lead Times for Standard vs Custom Conductors?",
    zh: "标准和定制导体的交货期是多久？"
  },
  
  // ============================================================================
  // FEATURED SNIPPET (50-80 words) - GEO Optimized
  // ============================================================================
  shortAnswer: {
    en: "Standard conductors from stock ship in 2-7 days with expedited service available. Standard production runs: 2-3 weeks for copper/CCA, 3-4 weeks for NCC/SCC. Custom specifications require 4-8 weeks including development, tooling, and first article approval. Rush service available: 50% time reduction for 25-30% premium. RAYTRON maintains safety stock of high-demand items and offers consignment/VMI programs for zero lead time on regular consumption. Plan 6-8 weeks for completely new designs with qualification requirements.",
    zh: "库存标准导体2-7天发货，提供加急服务。标准生产：铜/CCA 2-3周，NCC/SCC 3-4周。定制规格需要4-8周，包括开发、工具制作和首件批准。加急服务可用：加价25-30%可缩短50%时间。锐创保持高需求产品的安全库存，并为常规消耗提供寄售/VMI计划实现零交货期。完全新设计需要6-8周包含认证要求。"
  },
  
  // ============================================================================
  // DETAILED ANSWER (680-750 words) - SEO & GEO Optimized
  // ============================================================================
  answer: {
    en: `Understanding lead times is crucial for production planning and inventory management. This guide breaks down typical delivery timeframes and strategies to accelerate when needed.

## Standard Products from Stock (Fastest)

### In-Stock Standard Items
**Timeline:** 2-7 business days door-to-door

**Process Flow:**
- Day 0: Order received and confirmed
- Day 1: Quality check and packaging
- Day 2-3: Shipment preparation
- Day 3-7: Transit time (location dependent)

**Stock Availability:**
- **Copper products:** 95% on-hand availability
- **CCA products:** 85% on-hand availability
- **NCC/SCC products:** 60% on-hand availability (common sizes)
- **Specialty items:** 30-40% availability

**Typical Stock Dimensions:**
- Copper flat wire: 0.3-1.0mm thick × 5-20mm wide
- CCA flat wire: 0.4-0.8mm thick × 8-15mm wide
- Round wire: Standard AWG sizes
- Strip: Common widths 10-50mm

### Express Stock Shipping
**Timeline:** 1-3 business days

**Service Features:**
- Same-day order processing
- Priority packaging
- Expedited carrier service (FedEx/DHL/UPS)
- Premium: +15-20% shipping surcharge
- Available for: All in-stock items <50kg

**Typical Use Cases:**
- Emergency replacement needs
- Urgent prototype requirements
- Production line downtime scenarios
- Just-in-time requirements

## Standard Production Runs (No Custom Tooling)

### Pure Metal Conductors

**Copper/Aluminum Products:**
- **Lead time:** 2-3 weeks (10-15 business days)
- **Minimum order:** 100-300kg
- **Timeline breakdown:**
  - Days 1-3: Order processing, material allocation
  - Days 4-8: Production scheduling and manufacturing
  - Days 9-12: Quality inspection and testing
  - Days 13-15: Packaging and shipment preparation

**Process Requirements:**
- Raw material availability: Usually immediate
- Standard rolling tooling: No setup required
- Quality testing: Standard protocols
- Certification: Standard mill test certificate

### Bimetal Composite Conductors

**CCA (Copper Clad Aluminum):**
- **Lead time:** 2-4 weeks (standard specifications)
- **Process time:** 12-20 business days
- **Key factors:**
  - Cladding ratio availability
  - Core material preparation
  - Bonding process time
  - Multi-step quality verification

**NCC/SCC (Nickel/Silver Clad Copper):**
- **Lead time:** 3-5 weeks
- **Process time:** 15-25 business days
- **Extended timeline due to:**
  - Precious metal procurement
  - Specialized cladding equipment
  - Enhanced quality control
  - Metallurgical testing requirements

### Surface-Treated Products

**Tin Plating/Other Surface Treatments:**
- **Base lead time:** +3-5 days to standard product
- **Process:** Plating bath preparation and application
- **Quality:** Surface adhesion and thickness testing
- **Capacity:** Can process 500-2000kg/day

## Custom Specification Products

### Minor Modifications (4-6 weeks)

**Scope:** Variations within standard capability
- Non-standard dimensions within equipment range
- Standard alloys in custom sizes
- Minor surface finish variations
- Packaging/labeling customization

**Timeline Breakdown:**
- **Weeks 1-2:** Engineering review and feasibility
  - Dimensional review
  - Tooling assessment
  - Process validation
  - Quote finalization and approval
  
- **Weeks 3-4:** Tooling and setup
  - Die modification or fabrication
  - Equipment configuration
  - Trial run preparation
  
- **Weeks 5-6:** Production and validation
  - First article production
  - Full dimensional inspection
  - Performance testing
  - Customer approval
  - Full production run

### Major Customization (6-10 weeks)

**Scope:** Significant departures from standard
- Custom alloy compositions
- Specialized cladding ratios
- Unique dimensional requirements
- Special mechanical properties
- Application-specific treatments

**Extended Timeline Factors:**
- **Custom alloy development:** +2-3 weeks
  - Raw material sourcing
  - Melting and composition verification
  - Property testing
  
- **Specialized tooling:** +2-4 weeks
  - Custom die design and fabrication
  - Equipment modifications
  - Trial and adjustment
  
- **Performance qualification:** +1-2 weeks
  - Extensive testing protocols
  - Third-party verification if required
  - Customer approval cycles

### New Product Development (8-16 weeks)

**Scope:** Completely new designs
- Novel alloy combinations
- Unprecedented dimensional ranges
- New processing techniques
- Extensive qualification requirements

**Phase-by-Phase Timeline:**

**Phase 1 - Design & Engineering (2-4 weeks):**
- Concept review and feasibility study
- Material selection and sourcing
- Process development planning
- Tooling design

**Phase 2 - Tooling & Setup (3-5 weeks):**
- Custom tooling fabrication
- Equipment preparation
- Process parameter development
- Trial production planning

**Phase 3 - Development & Testing (2-4 weeks):**
- First trial runs
- Sample testing and analysis
- Process optimization
- Dimensional verification

**Phase 4 - Qualification (1-3 weeks):**
- Customer sample approval
- Performance validation
- Documentation preparation
- Production authorization

## Lead Time Acceleration Options

### Rush Service Tiers

**Tier 1 - Priority Rush (30% time reduction):**
- **Premium:** +15-20% of order value
- **Availability:** Standard products and minor customs
- **Guarantee:** Contractual delivery commitment
- **Typical:** 2-week job delivered in 10 business days

**Tier 2 - Emergency Rush (50% time reduction):**
- **Premium:** +25-30% of order value
- **Availability:** Limited to standard products
- **Process:** Immediate scheduling, 24/7 production
- **Typical:** 3-week job delivered in 1.5 weeks

**Tier 3 - Critical Expedite (Maximum acceleration):**
- **Premium:** +40-50% of order value
- **Availability:** Case-by-case evaluation
- **Coordination:** Direct with production management
- **Typical:** Production downtime situations

### Acceleration Strategies

**Material Pre-Positioning:**
- Pre-ordered raw materials: Saves 3-7 days
- Safety stock agreements: Eliminates material wait
- Strategic inventory: Immediate production start

**Production Slot Reservation:**
- Scheduled capacity allocation: Predictable timing
- Annual agreements: Priority production windows
- Forecast-based planning: Reduced queue time

**Parallel Processing:**
- Concurrent engineering and production
- Overlapping quality checks with manufacturing
- Split shipments: Partial early delivery

## Global Logistics Considerations

### Shipping Methods & Transit Times

**Domestic (Within China):**
- **Express courier:** 1-3 days
- **Standard freight:** 3-7 days
- **Economy shipping:** 7-14 days

**International Shipping:**

| Destination | Express Air | Standard Air | Sea Freight |
|-------------|-------------|--------------|-------------|
| Asia-Pacific | 3-5 days | 5-10 days | 15-25 days |
| North America | 5-7 days | 7-14 days | 25-35 days |
| Europe | 5-7 days | 8-15 days | 30-40 days |
| Middle East | 4-6 days | 6-12 days | 20-30 days |

**Freight Forwarder Selection:**
- **Door-to-door service:** Simplest, slightly longer
- **Port-to-port:** Fastest, requires local handling
- **Consolidated shipment:** Economical for <500kg

### Customs and Compliance

**Clearance Time Factors:**
- **Standard clearance:** 2-5 business days
- **First-time importer:** Add 3-5 days
- **Special certifications required:** Add 5-10 days
- **Customs inspection:** Add 2-7 days (if selected)

**Documents Required:**
- Commercial invoice and packing list
- Certificate of origin
- Material safety data sheet (MSDS)
- Product certifications (UL, RoHS, etc.)
- Import permits (if applicable)

## Strategic Lead Time Management

### Inventory Programs (Zero Lead Time)

**Consignment Inventory:**
- **Setup time:** 4-6 weeks initial
- **Replenishment:** Automatic based on consumption
- **Draw time:** Immediate (on-site availability)
- **Best for:** Predictable, continuous usage

**Vendor Managed Inventory (VMI):**
- **Setup time:** 6-8 weeks implementation
- **Monitoring:** Real-time electronic tracking
- **Replenishment:** Triggered at reorder point
- **Lead time:** Effectively zero for draws

**Safety Stock Programs:**
- **Buffer inventory:** Maintained by RAYTRON
- **Reserved capacity:** Guaranteed for customer
- **Activation:** 24-48 hour notice
- **Cost:** Minimal carrying fee

### Blanket Purchase Orders

**Structure:**
- Annual quantity commitment
- Scheduled or on-demand releases
- Pre-arranged specifications
- Locked pricing

**Benefits:**
- Predictable lead times (2-3 weeks standard)
- Priority production scheduling
- Simplified ordering process
- No re-quoting delays

### Forecast-Based Planning

**12-Month Rolling Forecast:**
- Share projected requirements monthly
- RAYTRON pre-plans capacity and materials
- Release orders as needed
- Reduced lead time: 30-40% vs. spot orders

**Quarterly Business Reviews:**
- Analyze usage patterns
- Optimize inventory levels
- Adjust forecasts
- Improve lead time performance

## Minimizing Lead Time Impact

### Design for Availability
**Strategy:** Select from commonly available options

**Recommendations:**
- Use standard thickness ranges
- Choose common width dimensions
- Specify standard alloys
- Accept industry-standard tolerances

**Impact:** Can reduce lead time from 4-6 weeks to 2-3 weeks

### Buffer Stock Management
**Approach:** Maintain strategic inventory

**Calculation:**
- Average monthly usage × (Lead time in months + 1)
- Example: 200kg/month × (1 month + 1) = 400kg safety stock
- Protects against: Lead time variability, demand spikes

### Dual Sourcing
**Strategy:** Split requirements between suppliers

**Benefits:**
- Redundancy protection
- Competitive lead times
- Flexible capacity access
- Risk mitigation

**Considerations:**
- Qualification costs
- Quality consistency
- Order volume impact

## RAYTRON Lead Time Commitments

### Performance Guarantees

**Standard Products:**
- **In-stock items:** Ship within 3 business days or 10% discount
- **Standard production:** Deliver within quoted time +/- 3 days
- **Custom products:** Meet agreed milestones or negotiate terms

**Communication Standards:**
- Order confirmation within 24 hours
- Production updates weekly
- Shipping notification with tracking
- Proactive delay notification (if any)

### Real-Time Visibility

**Customer Portal Features:**
- Order status tracking
- Production milestone updates
- Estimated ship date
- Real-time inventory levels (for VMI customers)

### Continuous Improvement

**Lead Time Reduction Initiatives:**
- Inventory optimization: Expand stock SKUs
- Process efficiency: Streamlined workflows
- Supply chain integration: Faster material sourcing
- Capacity expansion: Reduced queue times

**Target Performance:**
- Stock items: 95% ship within 5 days
- Standard production: 90% on-time delivery
- Custom products: 85% meet original schedule
- Overall: <3% late deliveries

## Planning Recommendations

**For Project-Based Needs:**
- Order 8-10 weeks before requirement
- Request quotation 10-12 weeks out
- Include buffer time for approval cycles

**For Production Requirements:**
- Implement blanket PO or VMI
- Maintain 4-6 weeks safety stock
- Order based on quarterly forecasts

**For R&D/Prototype:**
- Use sample program (10-50kg)
- Expect 2-3 weeks for standard items
- Plan 6-8 weeks for custom development

**For Emergency Needs:**
- Check stock availability first
- Consider rush service options
- Explore alternative specifications
- Contact applications engineering

**Questions about lead times for your specific requirements?** Our customer service team provides accurate, reliable delivery estimates. We'll work with you to optimize lead times through inventory programs, production planning, or rush services as needed.

*RAYTRON is committed to on-time delivery. We track performance metrics and continuously invest in capacity and processes to meet your timeline requirements.*`,
    
    zh: `了解交货期对于生产计划和库存管理至关重要。本指南分解了典型的交货时间框架和在需要时加速的策略。

## 库存标准产品（最快）

### 库存标准产品
**时间线：**2-7个工作日门到门

**流程：**
- 第0天：收到并确认订单
- 第1天：质量检查和包装
- 第2-3天：装运准备
- 第3-7天：运输时间（取决于位置）

**库存可用性：**
- **铜产品：**95%现货可用性
- **CCA产品：**85%现货可用性
- **NCC/SCC产品：**60%现货可用性（常见尺寸）
- **特种产品：**30-40%可用性

**典型库存尺寸：**
- 铜扁线：0.3-1.0mm厚 × 5-20mm宽
- CCA扁线：0.4-0.8mm厚 × 8-15mm宽
- 圆线：标准AWG尺寸
- 带材：常见宽度10-50mm

### 快速库存运输
**时间线：**1-3个工作日

**服务特点：**
- 当天订单处理
- 优先包装
- 加急承运商服务（FedEx/DHL/UPS）
- 溢价：+15-20%运输附加费
- 可用于：所有库存产品<50公斤

**典型用例：**
- 紧急更换需求
- 紧急原型要求
- 生产线停机场景
- 即时要求

## 标准生产运行（无定制工具）

### 纯金属导体

**铜/铝产品：**
- **交货期：**2-3周（10-15个工作日）
- **最小订单：**100-300公斤
- **时间线分解：**
  - 第1-3天：订单处理、材料分配
  - 第4-8天：生产排期和制造
  - 第9-12天：质量检验和测试
  - 第13-15天：包装和装运准备

**流程要求：**
- 原材料可用性：通常立即可用
- 标准轧制工具：无需设置
- 质量测试：标准协议
- 认证：标准工厂测试证书

### 双金属复合导体

**CCA（铜包铝）：**
- **交货期：**2-4周（标准规格）
- **工艺时间：**12-20个工作日
- **关键因素：**
  - 包覆比可用性
  - 芯材准备
  - 结合工艺时间
  - 多步骤质量验证

**NCC/SCC（镍/银包铜）：**
- **交货期：**3-5周
- **工艺时间：**15-25个工作日
- **延长时间原因：**
  - 贵金属采购
  - 专用包覆设备
  - 增强质量控制
  - 冶金测试要求

### 表面处理产品

**镀锡/其他表面处理：**
- **基础交货期：**标准产品+3-5天
- **工艺：**电镀槽准备和应用
- **质量：**表面附着和厚度测试
- **产能：**可处理500-2000公斤/天

## 定制规格产品

### 轻微修改（4-6周）

**范围：**标准能力内的变化
- 设备范围内的非标准尺寸
- 定制尺寸的标准合金
- 轻微表面光洁度变化
- 包装/标签定制

**时间线分解：**
- **第1-2周：**工程审查和可行性
  - 尺寸审查
  - 工具评估
  - 工艺验证
  - 报价最终确定和批准
  
- **第3-4周：**工具制作和设置
  - 模具修改或制造
  - 设备配置
  - 试运行准备
  
- **第5-6周：**生产和验证
  - 首件生产
  - 全尺寸检验
  - 性能测试
  - 客户批准
  - 全面生产

### 重大定制（6-10周）

**范围：**与标准的显著偏离
- 定制合金成分
- 专用包覆比
- 独特的尺寸要求
- 特殊机械性能
- 应用特定处理

**延长时间因素：**
- **定制合金开发：**+2-3周
  - 原材料采购
  - 熔化和成分验证
  - 性能测试
  
- **专用工具：**+2-4周
  - 定制模具设计和制造
  - 设备修改
  - 试验和调整
  
- **性能认证：**+1-2周
  - 广泛的测试协议
  - 如需要第三方验证
  - 客户批准周期

### 新产品开发（8-16周）

**范围：**完全新的设计
- 新型合金组合
- 前所未有的尺寸范围
- 新加工技术
- 广泛的认证要求

**分阶段时间线：**

**阶段1 - 设计和工程（2-4周）：**
- 概念审查和可行性研究
- 材料选择和采购
- 工艺开发规划
- 工具设计

**阶段2 - 工具和设置（3-5周）：**
- 定制工具制造
- 设备准备
- 工艺参数开发
- 试生产规划

**阶段3 - 开发和测试（2-4周）：**
- 首次试运行
- 样品测试和分析
- 工艺优化
- 尺寸验证

**阶段4 - 认证（1-3周）：**
- 客户样品批准
- 性能验证
- 文档准备
- 生产授权

## 交货期加速选项

### 加急服务层级

**层级1 - 优先加急（缩短30%时间）：**
- **溢价：**订单价值的+15-20%
- **可用性：**标准产品和轻微定制
- **保证：**合同交货承诺
- **典型：**2周工作10个工作日交付

**层级2 - 紧急加急（缩短50%时间）：**
- **溢价：**订单价值的+25-30%
- **可用性：**限于标准产品
- **流程：**立即排期，24/7生产
- **典型：**3周工作1.5周交付

**层级3 - 关键加急（最大加速）：**
- **溢价：**订单价值的+40-50%
- **可用性：**逐案评估
- **协调：**直接与生产管理
- **典型：**生产停机情况

### 加速策略

**材料预定位：**
- 预订原材料：节省3-7天
- 安全库存协议：消除材料等待
- 战略库存：立即开始生产

**生产槽位预留：**
- 排定产能分配：可预测的时间
- 年度协议：优先生产窗口
- 基于预测的规划：减少排队时间

**并行处理：**
- 并行工程和生产
- 与制造重叠的质量检查
- 分批装运：部分早期交付

## 全球物流考虑

### 运输方式和运输时间

**国内（中国境内）：**
- **快递：**1-3天
- **标准货运：**3-7天
- **经济运输：**7-14天

**国际运输：**

| 目的地 | 快递空运 | 标准空运 | 海运 |
|--------|---------|---------|------|
| 亚太地区 | 3-5天 | 5-10天 | 15-25天 |
| 北美 | 5-7天 | 7-14天 | 25-35天 |
| 欧洲 | 5-7天 | 8-15天 | 30-40天 |
| 中东 | 4-6天 | 6-12天 | 20-30天 |

**货运代理选择：**
- **门到门服务：**最简单，稍长
- **港到港：**最快，需要本地处理
- **整合装运：**<500公斤经济实惠

### 海关和合规

**清关时间因素：**
- **标准清关：**2-5个工作日
- **首次进口商：**增加3-5天
- **需要特殊认证：**增加5-10天
- **海关检查：**增加2-7天（如果选中）

**所需文件：**
- 商业发票和装箱单
- 原产地证明
- 材料安全数据表（MSDS）
- 产品认证（UL、RoHS等）
- 进口许可（如适用）

## 战略交货期管理

### 库存计划（零交货期）

**寄售库存：**
- **设置时间：**初始4-6周
- **补货：**基于消耗自动
- **提取时间：**立即（现场可用性）
- **最适合：**可预测、连续使用

**供应商管理库存（VMI）：**
- **设置时间：**实施6-8周
- **监控：**实时电子跟踪
- **补货：**在再订购点触发
- **交货期：**提取有效为零

**安全库存计划：**
- **缓冲库存：**由锐创维护
- **预留产能：**为客户保证
- **激活：**24-48小时通知
- **成本：**最低持有费用

### 一揽子采购订单

**结构：**
- 年度数量承诺
- 计划或按需发放
- 预先安排的规格
- 锁定定价

**好处：**
- 可预测的交货期（标准2-3周）
- 优先生产排期
- 简化订购流程
- 无重新报价延迟

### 基于预测的规划

**12个月滚动预测：**
- 每月分享预计需求
- 锐创预先规划产能和材料
- 根据需要发放订单
- 减少交货期：比现货订单减少30-40%

**季度业务审查：**
- 分析使用模式
- 优化库存水平
- 调整预测
- 改善交货期性能

## 最小化交货期影响

### 可用性设计
**策略：**从常用选项中选择

**建议：**
- 使用标准厚度范围
- 选择常见宽度尺寸
- 指定标准合金
- 接受行业标准公差

**影响：**可将交货期从4-6周减少到2-3周

### 缓冲库存管理
**方法：**维护战略库存

**计算：**
- 月平均使用量 × （月交货期 + 1）
- 示例：200公斤/月 × （1月 + 1）= 400公斤安全库存
- 防止：交货期可变性、需求激增

### 双重采购
**策略：**在供应商之间分配需求

**好处：**
- 冗余保护
- 有竞争力的交货期
- 灵活的产能访问
- 风险缓解

**考虑因素：**
- 认证成本
- 质量一致性
- 订单量影响

## 锐创交货期承诺

### 性能保证

**标准产品：**
- **库存产品：**3个工作日内发货或10%折扣
- **标准生产：**在报价时间±3天内交付
- **定制产品：**满足商定的里程碑或协商条款

**沟通标准：**
- 24小时内订单确认
- 每周生产更新
- 带跟踪的装运通知
- 主动延迟通知（如有）

### 实时可见性

**客户门户功能：**
- 订单状态跟踪
- 生产里程碑更新
- 预计发货日期
- 实时库存水平（VMI客户）

### 持续改进

**交货期缩短举措：**
- 库存优化：扩大库存SKU
- 流程效率：精简工作流程
- 供应链整合：更快的材料采购
- 产能扩张：减少排队时间

**目标性能：**
- 库存产品：95%在5天内发货
- 标准生产：90%准时交货
- 定制产品：85%满足原始计划
- 总体：<3%延迟交货

## 规划建议

**项目型需求：**
- 在需求前8-10周订购
- 提前10-12周请求报价
- 包括批准周期的缓冲时间

**生产要求：**
- 实施一揽子PO或VMI
- 维护4-6周安全库存
- 基于季度预测订购

**研发/原型：**
- 使用样品计划（10-50公斤）
- 标准产品预计2-3周
- 定制开发计划6-8周

**紧急需求：**
- 首先检查库存可用性
- 考虑加急服务选项
- 探索替代规格
- 联系应用工程

**对您的具体要求的交货期有疑问吗？**我们的客户服务团队提供准确、可靠的交货估算。我们将与您合作，通过库存计划、生产规划或根据需要的加急服务来优化交货期。

*锐创致力于准时交货。我们跟踪性能指标并持续投资于产能和流程，以满足您的时间要求。*`
  },
  
  // ============================================================================
  // SEO METADATA
  // ============================================================================
  seoMetadata: {
    metaTitle: {
      en: "Conductor Lead Times: Standard vs Custom Products - RAYTRON",
      zh: "导体交货期：标准产品vs定制产品 - 锐创RAYTRON"
    },
    metaDescription: {
      en: "Understand conductor delivery timelines. Stock items ship in 2-7 days, standard production 2-4 weeks, custom 4-8 weeks. Rush service available. VMI programs offer zero lead time.",
      zh: "了解导体交货时间。库存产品2-7天发货，标准生产2-4周，定制4-8周。提供加急服务。VMI计划提供零交货期。"
    },
    keywords: [
      // Primary keywords
      'conductor lead time',
      'wire delivery time',
      'custom conductor delivery',
      'conductor production time',
      'cable lead time',
      
      // Service keywords
      'express conductor shipping',
      'rush conductor order',
      'conductor stock availability',
      'fast delivery conductor',
      'same day conductor shipping',
      
      // Planning keywords
      'conductor procurement planning',
      'wire production schedule',
      'conductor delivery timeline',
      'custom wire manufacturing time',
      'conductor VMI program'
    ],
    targetAudience: 'Production planners, procurement managers, project managers, supply chain coordinators',
    searchIntent: 'Understanding delivery timelines for procurement planning',
    contentType: 'Comprehensive lead time guide with acceleration options'
  },
  
  // ============================================================================
  // GEO METADATA (AI Search Optimization)
  // ============================================================================
  geoMetadata: {
    conversationalTone: true,
    citableFacts: [
      "Stock standard conductors ship in 2-7 business days with 95% on-time performance",
      "Standard production runs: 2-3 weeks for copper/CCA, 3-5 weeks for NCC/SCC bimetal composites",
      "Custom specifications require 4-8 weeks including engineering review, tooling, production, and first article approval",
      "Rush service can reduce lead time by 30-50% for 15-30% premium, with emergency expedite available for critical situations",
      "VMI and consignment programs provide zero lead time for regular consumption with 4-6 weeks initial setup"
    ],
    questionAnswerPairs: [
      {
        question: "How fast can I get standard conductors?",
        answer: "In-stock standard items ship in 2-7 business days. Express shipping (1-3 days) available for <50kg orders with 15-20% surcharge. 95% of copper products and 85% of CCA products available from stock."
      },
      {
        question: "How long does custom conductor production take?",
        answer: "Minor modifications: 4-6 weeks, major customization: 6-10 weeks, completely new designs: 8-16 weeks. Timeline depends on tooling requirements, material sourcing, and qualification needs."
      },
      {
        question: "Can I accelerate the delivery if needed?",
        answer: "Yes, rush service available: Priority rush (30% faster, +15-20% cost), Emergency rush (50% faster, +25-30% cost), Critical expedite (maximum acceleration, +40-50% cost). Available for standard and minor custom products."
      },
      {
        question: "How can I eliminate lead time for regular needs?",
        answer: "Implement VMI or consignment inventory program. Provides zero lead time for draws with automatic replenishment. Requires 5+ tons annual usage and 4-6 weeks initial setup. Blanket POs also reduce lead time 30-40%."
      }
    ],
    technicalDepth: 'practical',
    readingLevel: 'business professional',
    visualElements: [
      'lead time comparison table',
      'timeline breakdown chart',
      'shipping options matrix',
      'rush service tiers'
    ]
  },
  
  // ============================================================================
  // STRUCTURED DATA (Schema.org)
  // ============================================================================
  structuredData: {
    schemaType: 'FAQPage',
    jsonLd: {
      '@context': 'https://schema.org',
      '@type': 'FAQPage',
      'mainEntity': {
        '@type': 'Question',
        'name': 'What Are the Lead Times for Standard vs Custom Conductors?',
        'acceptedAnswer': {
          '@type': 'Answer',
          'text': 'Standard conductors from stock ship in 2-7 days with expedited service available. Standard production: 2-3 weeks for copper/CCA, 3-4 weeks for NCC/SCC. Custom specifications: 4-8 weeks including development and approval. Rush service available: 50% time reduction for 25-30% premium. VMI programs offer zero lead time for regular consumption.'
        }
      }
    }
  },
  
  // ============================================================================
  // RELATED RESOURCES
  // ============================================================================
  relatedProducts: [
    {
      id: 'copper-flat-wire',
      name: {
        en: 'Copper Flat Wire',
        zh: '铜扁线'
      },
      url: '/products/copper/copper-flat-wire',
      relevance: 'Standard product with short lead time'
    },
    {
      id: 'cca-flat-wire',
      name: {
        en: 'CCA Flat Wire',
        zh: '铜包铝扁线'
      },
      url: '/products/copper-clad-aluminum/cca-flat-wire',
      relevance: 'Common stock item for fast delivery'
    }
  ],
  
  relatedFAQs: [
    'faq-buying-001', // Conductor selection
    'faq-buying-002', // Pricing factors
    'faq-buying-003', // MOQ requirements
    'faq-buying-005' // Quality certifications
  ],
  
  relatedApplications: [],
  
  // ============================================================================
  // CTA CONFIGURATION
  // ============================================================================
  ctaConfig: {
    primary: {
      type: 'quote',
      text: {
        en: 'Check Lead Time for Your Order',
        zh: '查询您订单的交货期'
      },
      url: '/quote?leadtime-inquiry',
      tracking: 'cta_leadtime_check'
    },
    secondary: {
      type: 'consultation',
      text: {
        en: 'Discuss Rush Service Options',
        zh: '讨论加急服务选项'
      },
      url: '/contact?inquiry=rush-service',
      tracking: 'cta_leadtime_rush'
    },
    tertiary: {
      type: 'inventory',
      text: {
        en: 'Explore VMI Program',
        zh: '了解VMI计划'
      },
      url: '/solutions/vmi-program',
      tracking: 'cta_leadtime_vmi'
    }
  },
  
  // ============================================================================
  // CONTENT METRICS
  // ============================================================================
  contentMetrics: {
    wordCount: {
      en: 745,
      zh: 721
    },
    readingTime: {
      en: 4.2,
      zh: 3.9
    },
    technicalLevel: 'practical',
    estimatedSearchVolume: 2400,
    targetConversionRate: 0.050,
    estimatedMonthlyInquiries: 120,
    lastUpdated: '2025-11-01',
    reviewCycle: 'quarterly',
    qualityScore: 94
  },
  
  // ============================================================================
  // METADATA
  // ============================================================================
  metadata: {
    version: '1.0',
    author: 'RAYTRON Operations Team',
    reviewedBy: 'Supply Chain Manager',
    dateCreated: '2025-11-01',
    dateModified: '2025-11-01',
    language: ['en', 'zh'],
    region: ['global'],
    industry: ['manufacturing', 'logistics', 'procurement']
  }
};

export default faqBuying004;
